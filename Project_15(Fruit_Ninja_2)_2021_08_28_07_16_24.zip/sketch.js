var PLAY = 1;
var END = 0;
var score;
gameState = 1;
var fruits,sword;
var fruitGroup;
var monster,EnemyGroup;

function preload(){
  swordImg = loadImage("sword.png");
                       
  moving = loadAnimation("alien1.png","alien2.png");
  
  fruit1Img = loadImage("fruit1.png");
  fruit2Img = loadImage("fruit2.png");
  fruit3Img = loadImage("fruit3.png");
  fruit4Img = loadImage("fruit4.png");
  
  gameOverSound = loadSound("gameover.mp3");
  knifeSound = loadSound("knifeSwooshSound.mp3");
  
  gameOverImg = loadImage("gameover.png");
      
      
      
      
    
  }
 function setup(){
    createCanvas(600,600);
 
  
   EnemyGroup = createGroup();
   fruitGroup = createGroup();
  
   sword = createSprite();
   sword.addImage(swordImg);
   sword.scale = 0.5;
   

   score = 0;
   
   
   
    
   
 }

function draw(){
   background(25,25,112);
  

  
 text("score:"+score,280,30);

   sword.y = World.mouseY;
   sword.x = World.mouseX;

  
    if(gameState == 1){
    fruits();
    Enemy();
  }
    
   if(fruitGroup.isTouching(sword)){
     fruitGroup.destroyEach();
     knifeSound.play();
     score = score+1;
   }
 

     if(EnemyGroup.isTouching(sword)){
       gameState = END;
       gameOverSound.play();
   }
  
  if(gameState=== END) {
     sword.addImage(gameOverImg);
     sword.y = 250;
     sword.x = 300;
     fruitGroup.destroyEach();
     EnemyGroup.destroyEach();
     fruit.velocityX = 0;
    
    
  }
  drawSprites();
  
}



 function fruits(){
   if(World.frameCount%80 === 0 ){
     
      position = Math.round(random(1,2));
      fruit = createSprite(600,200,20,20);
      fruit.scale = 0.2;
      
      r = Math.round(random(1,4));
        if(r == 1){
          fruit.addImage(fruit1Img);
        } else if (r == 2){
          fruit.addImage(fruit2Img);
        } else if (r == 3){
          fruit.addImage(fruit3Img);
        } else if (r == 4){
          fruit.addImage(fruit4Img);
        }
         
        fruit.y = Math.round(random(50,340));
     
        if(position == 1){
          fruit.x = 600;
          fruit.velocityX = -(7+(score/2));
        }else if (position == 2){
          fruit.x = 0;
          fruit.velocityX = (7+(score/2));
        }
     
       
        fruit.setLifetime = 100;
     
        
        fruitGroup.add(fruit);
       }
 }
   
   function Enemy(){
     if(World.frameCount%200 === 0){
        monster = createSprite(600,300,20,20);
        monster.y = Math.round(random(100,300));
        monster.addAnimation("move",moving);
        monster.velocityX = -(10+(score/1));
        monster.setLifetime = 50;
        
        position = Math.round(random(1,2));
        
       if(position == 1){
         monster.x = 0;
         monster.velocityX = (10+(score/1));
       }else if (position == 2){
         monster.x = 600;
         monster.velocityX = -(10+(score/1));
     
       }

       EnemyGroup.add(monster);
     }

   }

